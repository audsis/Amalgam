<p align="center">
  <a href="https://nightly.link/rei-kes/Amalgam/workflows/msbuild/master/Amalgamx64Release.zip">
    <img src=".github/assets/download.png" alt="Download Button" width="auto" height="auto" align="center">
  </a>
  <a href="https://nightly.link/rei-kes/Amalgam/workflows/msbuild/master/Amalgamx64ReleaseAVX2.zip">
    <img src=".github/assets/download_avx2.png" alt="Download Button" width="auto" height="auto" align="center">
  </a>
</p>

# Amalgam

[![GitHub Repo stars](https://img.shields.io/github/stars/rei-kes/Amalgam)](/../../stargazers)
[![Discord](https://img.shields.io/discord/1227898008373297223?logo=Discord&label=discord)](https://discord.gg/RbP9DfkUhe)
[![GitHub Workflow Status (with event)](https://img.shields.io/github/actions/workflow/status/rei-kes/Amalgam/msbuild.yml?branch=master)](/../../actions)
[![GitHub commit activity (branch)](https://img.shields.io/github/commit-activity/m/rei-kes/Amalgam)](/../../commits/)