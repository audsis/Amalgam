#pragma once
#include "ButtonCode.h"

typedef ButtonCode_t KeyCode;