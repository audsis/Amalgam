#include "AutoUber.h"

#include "../../Players/PlayerUtils.h"

// this will be rewritten soon

void CAutoUber::Run(CTFPlayer* pLocal, CTFWeaponBase* pWeapon, CUserCmd* pCmd)
{

}