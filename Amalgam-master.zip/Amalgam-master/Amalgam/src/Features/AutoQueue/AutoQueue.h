#pragma once
#include "../../SDK/SDK.h"

class CAutoQueue
{
public:
	void Run();
};

ADD_FEATURE(CAutoQueue, AutoQueue);